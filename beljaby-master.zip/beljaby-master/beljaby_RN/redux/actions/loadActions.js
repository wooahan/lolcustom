export const setLoading = () => ({
    type: 'LOADING',
})
export const setFalse = () => ({
    type: 'SETFALSE'
})

export const setTrue = () => ({
    type: 'SETTRUE'
})
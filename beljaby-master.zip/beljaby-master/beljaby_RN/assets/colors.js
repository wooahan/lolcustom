
export const calendarColor = '#DE350F'
export const baseColor = '#DD3500'
export const disableColor = '#C4C4C4'
export const registerColor= '#421EB7'
export const black = "#000000"
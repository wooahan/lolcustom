// riot API config
export const riotApiKey = process.env.REACT_APP_RIOT_API_KEY;
export const firebaseKey = process.env.REACT_APP_FIREBASE_API_KEY;
